ALTER TABLE groups_users
ADD COLUMN status INTEGER CHECK (status IN (1, 0));