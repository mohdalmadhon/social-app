export class Notification {
    
}